/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (C) 2012 ARM Ltd.
 */
#ifndef __ASM_FB_H_
#define __ASM_FB_H_

#include <asm-generic/fb.h>

#endif /* __ASM_FB_H_ */
